# RepoScraper
Assets for Sileo's built-in repo scraper
### Current Repositories Supported:
  * [BigBoss](https://moreinfo.thebigboss.org)
  * [MacCiti](http://cydia.saurik.com/macciti/)
  * [Matchstic](https://repo.incendo.ws)
  * [Rpetrich](https://rpetri.ch/cydia)
  
